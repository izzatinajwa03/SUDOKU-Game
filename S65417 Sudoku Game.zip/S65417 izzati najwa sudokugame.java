package com.mycompany.sudokugame;
import java.util.Scanner;
import java.lang.Math;

/************************************************************************************************
 * Author Name: Nur izzati Najwa Binti Mohd Bakhri
 * Matric NO: S65417
 * Program Name: Sudokugame.java
 * Course: Mobile Computing
 * Date: 3/12/2022
 */
public class Sudokugame {
    
//we define simple grid to solve. Grid is stored in 2D array
    public static int[][]GRID_TO_SOLVE= { 
        {9,5,0,0,1,0,2,0,0},
        {0,8,0,0,0,7,0,9,6},
        {6,0,2,8,0,0,5,3,0},
        {0,7,0,3,6,0,0,0,2},
        {5,0,0,9,0,1,3,6,0},
        {0,6,9,0,2,8,0,4,0},
        {8,0,5,0,0,2,6,1,3},
        {0,9,1,4,3,0,0,7,0},
        {0,0,6,0,8,0,4,0,0},
        
    };
    
    private int[][] board;
    public static final int EMPTY=0; //empty cell
    public static final int SIZE=9; //size of sudoku grids
    
    public Sudokugame(int[][] board)  {
        this.board=new int[SIZE][SIZE];
        
        for (int i=0; i < SIZE; i++) {
            for (int j=0; j< SIZE; j++){
                this.board[i][j] = board[i][j];
            }
            
         }
        }
        
        //we check if a possible number is already in a row
    private boolean isInRow(int row, int number) {
        for (int i = 0; i < SIZE; i++)
           if (board[row][i] == number)
               return true;
        
        return false;
        
    }
       
    //we check if a possible number is already in a column
    private boolean isInCol(int col, int number) {
         for (int i = 0; i < SIZE; i++)
           if (board[i][col] == number)
               return true;
        
        return false;
    }
      
    //we check if a possible number is in its 3*3 box
    private boolean isInBox(int row, int col, int number)  {
        int r = row - row % 3;
        int c = col - col % 3;
        
        for (int i = r; i < r + 3; i++)
            for (int j = c; j < c + 3; j++)
                if (board[i][j] == number)
                    return true;
        
        return false;
       
    }
       
    //combined method to check if number possible to a row,col position is ok
    private boolean isOk(int row, int col, int number) {
        return !isInRow(row, number) && !isInCol(col, number) && !isInBox(row, col, number);
        
    }
    
    //solved method.
    public boolean solve() {
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++)  {
                //search an empty cell
                if (board[row][col] == EMPTY) {
                    //try any possible number
                    for (int number = 1; number <= SIZE; number++) {
                        if (isOk(row, col, number)) {
                            //number ok and respects sudoku constraints
                            board[row][col] = number;
                            
                            if (solve()) {  
                                return true;
                                
                            } else { 
                                board[row][col] = EMPTY;
                                
                            }
                        }
                    }
                    
                    return false;
                }
            }
        }
        
        return true; //sudoku solved
       
     }
    
    public void display() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                System.out.println(" " + board[i][j]);
                
            }
            
            System.out.println();
        }
        
        System.out.println();
        
    }
    
    public static void main(String[]args) {
        Sudokugame sudoku = new Sudokugame(GRID_TO_SOLVE);
        System.out.println("Sudoku grid to solve");
        sudoku.display();
        
        if (sudoku.solve()) {
           System.out.println("Sudoku grid finally solved");
           sudoku.display();
           
        } else {
            System.out.println("Sudoku is unsolvable");
        }
    }
    }
            